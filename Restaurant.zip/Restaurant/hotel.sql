-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2021 at 11:34 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`Email`, `Password`) VALUES
('provat3@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `doubleac`
--

CREATE TABLE `doubleac` (
  `sno` int(2) NOT NULL,
  `rno` int(4) NOT NULL,
  `holder_name` varchar(20) NOT NULL,
  `holder_id` int(7) NOT NULL,
  `holder_mobile` varchar(15) NOT NULL,
  `holder_add` varchar(50) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doubleac`
--

INSERT INTO `doubleac` (`sno`, `rno`, `holder_name`, `holder_id`, `holder_mobile`, `holder_add`, `in_date`, `out_date`, `status`) VALUES
(1, 141, '', 0, '', '', '0000-00-00', '0000-00-00', 0),
(2, 142, '', 0, '', '', '0000-00-00', '0000-00-00', 0),
(3, 143, 'fgfd', 2234, '01996194878', 'rhrn4nq', '2000-03-13', '0200-03-15', 1),
(4, 144, 'fgfd', 2234, '343454e', 'ef2qvq', '2000-03-13', '2000-03-15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doublenonac`
--

CREATE TABLE `doublenonac` (
  `sno` int(2) NOT NULL,
  `rno` int(5) NOT NULL,
  `holder_name` varchar(20) NOT NULL,
  `holder_id` int(7) NOT NULL,
  `holder_mobile` varchar(15) NOT NULL,
  `holder_add` varchar(50) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doublenonac`
--

INSERT INTO `doublenonac` (`sno`, `rno`, `holder_name`, `holder_id`, `holder_mobile`, `holder_add`, `in_date`, `out_date`, `status`) VALUES
(1, 131, '', 0, '', '', '0000-00-00', '0000-00-00', 0),
(2, 132, '', 0, '', '', '0000-00-00', '0000-00-00', 0),
(2, 133, 'fgfd', 3343, '343454e', 'rt13t1', '2000-03-13', '2000-03-15', 1),
(3, 134, '', 0, '', '', '0000-00-00', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `singleac`
--

CREATE TABLE `singleac` (
  `sno` int(2) NOT NULL,
  `rno` int(4) NOT NULL,
  `holder_name` varchar(20) NOT NULL,
  `holder_id` int(7) NOT NULL,
  `holder_mobile` varchar(15) NOT NULL,
  `holder_add` varchar(50) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `singleac`
--

INSERT INTO `singleac` (`sno`, `rno`, `holder_name`, `holder_id`, `holder_mobile`, `holder_add`, `in_date`, `out_date`, `status`) VALUES
(1, 111, '', 0, '', '', '0000-00-00', '0000-00-00', 0),
(2, 112, '', 0, '', '', '0000-00-00', '0000-00-00', 0),
(3, 113, 'fgfd', 3343, '343454e', 'rrrrrrrrrrrrrrr', '2000-03-13', '0000-00-00', 1),
(4, 114, '', 0, '', '', '0000-00-00', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `singlenonac`
--

CREATE TABLE `singlenonac` (
  `sno` int(2) NOT NULL,
  `rno` int(5) NOT NULL,
  `holder_name` varchar(20) NOT NULL,
  `holder_id` int(8) NOT NULL,
  `holder_mobile` varchar(15) NOT NULL,
  `holder_add` varchar(60) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `singlenonac`
--

INSERT INTO `singlenonac` (`sno`, `rno`, `holder_name`, `holder_id`, `holder_mobile`, `holder_add`, `in_date`, `out_date`, `status`) VALUES
(1, 101, 't45tggt', 2234, '01996194878', 'yu468i', '2000-03-13', '2000-03-15', 1),
(2, 102, 'fgfd', 0, '01996194878', 'edtgfcy', '2000-03-13', '2000-03-15', 1),
(3, 103, '', 0, '', '', '0000-00-00', '0000-00-00', 1),
(4, 104, '', 0, '', '', '0000-00-00', '0000-00-00', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`Email`,`Password`);

--
-- Indexes for table `doubleac`
--
ALTER TABLE `doubleac`
  ADD PRIMARY KEY (`sno`,`rno`);

--
-- Indexes for table `doublenonac`
--
ALTER TABLE `doublenonac`
  ADD PRIMARY KEY (`sno`,`rno`);

--
-- Indexes for table `singleac`
--
ALTER TABLE `singleac`
  ADD PRIMARY KEY (`sno`,`rno`);

--
-- Indexes for table `singlenonac`
--
ALTER TABLE `singlenonac`
  ADD PRIMARY KEY (`sno`,`rno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doubleac`
--
ALTER TABLE `doubleac`
  MODIFY `sno` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doublenonac`
--
ALTER TABLE `doublenonac`
  MODIFY `sno` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `singleac`
--
ALTER TABLE `singleac`
  MODIFY `sno` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `singlenonac`
--
ALTER TABLE `singlenonac`
  MODIFY `sno` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
